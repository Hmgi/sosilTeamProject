﻿namespace MainProgram.Forms
{
    partial class FormConnect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIP = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txt_command = new System.Windows.Forms.TextBox();
            this.btnCmd = new System.Windows.Forms.Button();
            this.txt_log = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(12, 12);
            this.txtIP.Multiline = true;
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(272, 21);
            this.txtIP.TabIndex = 0;
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.btnConnect.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnConnect.Location = new System.Drawing.Point(290, 7);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 31);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txt_command
            // 
            this.txt_command.Location = new System.Drawing.Point(391, 12);
            this.txt_command.Name = "txt_command";
            this.txt_command.Size = new System.Drawing.Size(199, 21);
            this.txt_command.TabIndex = 2;
            // 
            // btnCmd
            // 
            this.btnCmd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnCmd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCmd.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.btnCmd.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnCmd.Location = new System.Drawing.Point(602, 7);
            this.btnCmd.Name = "btnCmd";
            this.btnCmd.Size = new System.Drawing.Size(75, 31);
            this.btnCmd.TabIndex = 3;
            this.btnCmd.Text = "CMD";
            this.btnCmd.UseVisualStyleBackColor = false;
            this.btnCmd.Click += new System.EventHandler(this.btnCmd_Click);
            // 
            // txt_log
            // 
            this.txt_log.Location = new System.Drawing.Point(12, 52);
            this.txt_log.Multiline = true;
            this.txt_log.Name = "txt_log";
            this.txt_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_log.Size = new System.Drawing.Size(665, 378);
            this.txt_log.TabIndex = 4;
            // 
            // FormConnect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(768, 442);
            this.Controls.Add(this.txt_log);
            this.Controls.Add(this.btnCmd);
            this.Controls.Add(this.txt_command);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtIP);
            this.DoubleBuffered = true;
            this.Name = "FormConnect";
            this.Text = "FormConnect";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txt_command;
        private System.Windows.Forms.Button btnCmd;
        private System.Windows.Forms.TextBox txt_log;
    }
}