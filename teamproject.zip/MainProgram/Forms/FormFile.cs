﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PacketLibrary;

namespace MainProgram.Forms
{
    public partial class FormFile : Form
    {
        private NetworkStream c_networkstream;
        private TcpClient c_client;

        private bool c_Connect = false;
        private Thread c_thread;

        private byte[] sendBuffer = new byte[10000000];
        private byte[] readBuffer = new byte[10000000];

        public Pathinfo c_Pathinfo;
        public TreeNode ExpandNode;
        public string FileName;
        public int DoubleClickExpand = 0;
        public string DownFile;
        public Fileinfo c_Fileinfo;
        public string Downroot;
        public string encryroot;

        public FormFile()
        {
            InitializeComponent();
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            string rootPath = txtRoot.Text;
            Paths Init = new Paths(rootPath);
            Init.Type = (int)PacketType.Init;
            Packet.Serialize(Init).CopyTo(this.sendBuffer, 0);
            this.Send();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            c_client = new TcpClient();
            c_client.Connect(this.txtIP.Text, 9003);
            c_Connect = true;
            c_networkstream = this.c_client.GetStream();
            
            c_thread = new Thread(new ThreadStart(RecivePacket));
            c_thread.Start();
        }

        public void RecivePacket()
        {
            int nRead;
            while (this.c_Connect)
            {
                try
                {
                    nRead = 0;
                    nRead = this.c_networkstream.Read(readBuffer, 0, 10000000);
                }
                catch
                {
                    this.c_Connect = false;
                    this.c_networkstream = null;
                }

                Packet packet = (Packet)Packet.Deserialize(this.readBuffer);

                switch ((int)packet.Type)
                {
                    case (int)PacketType.Init:
                        {
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                TreeNode root;
                                this.c_Pathinfo = (Pathinfo)Packet.Deserialize(this.readBuffer);
                                root = trvDir.Nodes.Add(c_Pathinfo.path);
                                if (trvDir.SelectedNode == null)
                                    trvDir.SelectedNode = root;
                                root.Nodes.Add("");
                            }));
                            break;
                        }
                    case (int)PacketType.Select:
                        {
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                ListViewItem item;
                                lvwFiles.Items.Clear();
                                this.c_Pathinfo = (Pathinfo)Packet.Deserialize(this.readBuffer);
                                foreach (DirectoryInfo tdis in c_Pathinfo.di)
                                {
                                    item = lvwFiles.Items.Add(tdis.Name);
                                    item.SubItems.Add("");
                                    item.SubItems.Add(tdis.LastWriteTime.ToString());
                                    item.ImageIndex = 0;
                                    item.Tag = "D";
                                }


                                foreach (FileInfo fis in c_Pathinfo.fi)
                                {
                                    string fileExtens = Path.GetExtension(fis.FullName);
                                    item = lvwFiles.Items.Add(fis.Name);
                                    item.SubItems.Add(fis.Length.ToString());
                                    item.SubItems.Add(fis.LastWriteTime.ToString());
                                    //음악
                                    if (fileExtens == ".mp3" || fileExtens == ".wav")
                                    {
                                        item.ImageIndex = 3;
                                    }
                                    //이미지
                                    else if (fileExtens == ".png")
                                    {
                                        item.ImageIndex = 2;
                                    }
                                    //텍스트
                                    else if (fileExtens == ".txt")
                                    {
                                        item.ImageIndex = 4;
                                    }
                                    //영상
                                    else if (fileExtens == ".avi" || fileExtens == ".mp4")
                                    {
                                        item.ImageIndex = 1;
                                    }
                                    else if (fileExtens == ".pdf")
                                    {
                                        item.ImageIndex = 6;
                                    }
                                    else if (fileExtens == ".jpg")
                                    {
                                        item.ImageIndex = 7;
                                    }
                                    else if (fileExtens == ".doc" || fileExtens == ".docx")
                                    {
                                        item.ImageIndex = 8;
                                    }
                                    else if (fileExtens == ".hwp")
                                    {
                                        item.ImageIndex = 9;
                                    }
                                    else if (fileExtens == ".enc")
                                    {
                                        item.ImageIndex = 10;
                                    }
                                    //그외
                                    else
                                    {
                                        item.ImageIndex = 5;
                                    }
                                    item.Tag = "F";
                                }
                            }));
                            break;
                        }
                    case (int)PacketType.Expand:
                        {
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                TreeNode tnode;
                                ExpandNode.Nodes.Clear();
                                this.c_Pathinfo = (Pathinfo)Packet.Deserialize(this.readBuffer);
                                foreach (DirectoryInfo dirs in c_Pathinfo.di)
                                {
                                    tnode = ExpandNode.Nodes.Add(dirs.Name);
                                    if (dirs.GetDirectories().Length > 0)
                                        tnode.Nodes.Add("");
                                }
                            }));
                            break;
                        }

                    case (int)PacketType.OpenItem:
                        {
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                TreeNode tnode;
                                ExpandNode.Nodes.Clear();
                                this.c_Pathinfo = (Pathinfo)Packet.Deserialize(this.readBuffer);
                                foreach (DirectoryInfo dirs in c_Pathinfo.di)
                                {
                                    tnode = ExpandNode.Nodes.Add(dirs.Name);
                                    if (dirs.GetDirectories().Length > 0)
                                        tnode.Nodes.Add("");
                                    if (tnode.Text == FileName)
                                    {
                                        trvDir.SelectedNode = tnode;
                                        trvDir.Focus();
                                    }
                                }

                            }));
                            break;
                        }

                    case (int)PacketType.다운로드:
                        {
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                this.c_Fileinfo = (Fileinfo)Packet.Deserialize(this.readBuffer);
                                FileInfo fi = c_Fileinfo.fileinfo;
                                fi.CopyTo(Downroot + "\\" + DownFile, true);
                            }));
                            break;

                        }
                }
            }
        }

        public void Send()
        {
            this.c_networkstream.Write(this.sendBuffer, 0, this.sendBuffer.Length);
            this.c_networkstream.Flush();
            for (int i = 0; i < 10000000; i++)
            {
                this.sendBuffer[i] = 0;
            }
        }

        private void trvDir_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (DoubleClickExpand == 0)
            {
                string path;
                ExpandNode = e.Node;
                path = e.Node.FullPath;

                Paths Expand = new Paths(path);
                Expand.Type = (int)PacketType.Expand;
                Packet.Serialize(Expand).CopyTo(this.sendBuffer, 0);
                this.Send();
            }

            if (DoubleClickExpand == 1)
            {
                string path;
                ExpandNode = e.Node;
                path = e.Node.FullPath;
                Paths OpenItem = new Paths(path);
                OpenItem.Type = (int)PacketType.OpenItem;
                Packet.Serialize(OpenItem).CopyTo(this.sendBuffer, 0);
                this.Send();
                DoubleClickExpand = 0;
            }
        }

        private void trvDir_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            string path;
            path = e.Node.FullPath;

            Paths Select = new Paths(path);
            Select.Type = (int)PacketType.Select;
            Packet.Serialize(Select).CopyTo(this.sendBuffer, 0);
            this.Send();
        }

        private void lvwFiles_DoubleClick(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection siList;
            siList = lvwFiles.SelectedItems;

            foreach (ListViewItem item in siList)
            {
                OpenItem(item);
            }
        }

        public void OpenItem(ListViewItem item)
        {
            TreeNode node;
            TreeNode child;
            if (item.Tag.ToString() == "D")
            {
                node = trvDir.SelectedNode;
                DoubleClickExpand = 1;
                FileName = item.Text;
                node.Expand();
                child = node.FirstNode;
                while (child != null)
                {
                    if (child.Text == item.Text)
                    {
                        trvDir.SelectedNode = child;
                        trvDir.Focus();
                        break;
                    }
                    child = child.NextNode;
                }
            }

            //상세정보
            /*else
            {
                node = trvDir.SelectedNode;
                FileName = node.FullPath + "\\" + item.Text;
                Paths Detail = new Paths(FileName);
                Detail.Type = (int)PacketType.상세정보;
                Packet.Serialize(Detail).CopyTo(this.sendBuffer, 0);
                this.Send();
            }*/
        }

        private void 다운로드ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection siList;
            siList = lvwFiles.SelectedItems;
            TreeNode node;
            string downFile;

            foreach (ListViewItem item in siList)
            {
                if (item.Tag.ToString() == "D")
                {
                    MessageBox.Show("폴더는 다운로드를 지원하지 않습니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    node = trvDir.SelectedNode;
                    downFile = node.FullPath + "\\" + item.Text;
                    DownFile = item.Text;

                    if(FB_Dlg.ShowDialog() == DialogResult.OK)
                    {
                        Downroot = FB_Dlg.SelectedPath;
                    }
                    Paths DownF = new Paths(downFile);
                    DownF.Type = (int)PacketType.다운로드;
                    Packet.Serialize(DownF).CopyTo(this.sendBuffer, 0);
                    this.Send();

                }
            }
        }

        private void 암호화ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection siList;
            siList = lvwFiles.SelectedItems;

            foreach (ListViewItem item in siList)
            {
                OpenEncry(item);
            }
        }
        public void OpenEncry(ListViewItem item)
        {
            
            TreeNode EncryNode = trvDir.SelectedNode;
            encryroot = EncryNode.FullPath;
            if (item.Tag.ToString() == "D")
            {
                MessageBox.Show("폴더는 암호화를 지원하지 않습니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Paths encry = new Paths(EncryNode.FullPath + "\\" + item.Text);
                encry.Type = (int)PacketType.암호화;
                Packet.Serialize(encry).CopyTo(this.sendBuffer, 0);
                this.Send();
            }
        }
    }
}
