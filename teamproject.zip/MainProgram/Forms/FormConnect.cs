﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PacketLibrary;

namespace MainProgram.Forms
{
    public partial class FormConnect : Form
    {
        public NetworkStream mainStream;
        public StreamReader m_Read;
        public StreamWriter m_Write;
        public TcpClient client;
        private Thread m_ThReader;
        private bool m_bClientOn = false;

        private byte[] sendBuffer = new byte[1024 * 100];
        private byte[] readBuffer = new byte[1024 * 100];

        public FormConnect()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            client = new TcpClient();
            client.Connect(this.txtIP.Text, 9001);
            if (client.Connected)
            {
                m_bClientOn = true;
                mainStream = client.GetStream();

                m_Read = new StreamReader(mainStream);
                m_Write = new StreamWriter(mainStream);

                m_ThReader = new Thread(new ThreadStart(Receive));
                m_ThReader.Start();
            }
        }

        public void Send()
        {
            mainStream.Write(this.sendBuffer, 0, this.sendBuffer.Length);
            mainStream.Flush();
            for (int i = 0; i < 1024 * 100; i++)
            {
                this.sendBuffer[i] = 0;
            }
        }
        public void Receive() // 실행 결과 수신
        {
            try
            {
                while (m_bClientOn)
                {
                    string msg = m_Read.ReadLine();
                    if (msg != null)
                        Message(msg);
                }
            }
            catch
            {
                MessageBox.Show("데이터 읽는 과정에서 오류 발생");
                return;
            }
        }

        private void btnCmd_Click(object sender, EventArgs e)
        {
            try
            {
                m_Write.WriteLine(txt_command.Text);
                m_Write.Flush();
            }
            catch
            {
                Message("데이터 전송 실패");
            }
        }

        public void Message(string msg) // log에 내용 출력
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                txt_log.AppendText(msg + "\r\n");
            }));
        }
    }
}
