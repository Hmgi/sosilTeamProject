﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net.Sockets;
using System.Drawing.Imaging;
using System.Drawing;

namespace PacketLibrary
{
    public enum PacketType
    {
        Init = 0,
        Screen_start,
        Select,
        Expand,
        OpenItem,
        다운로드,
        암호화
    }

    public enum PacketSendERROR
    {
        정상 = 0,
        에러
    }

    [Serializable]
    public class Packet
    {
        public int Type;

        public Packet()
        {
            this.Type = 0;
        }

        public static byte[] Serialize(Object obj)
        {
            MemoryStream ms = new MemoryStream(10000000);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, obj);
            return ms.ToArray();
        }

        public static Object Deserialize(byte[] bt)
        {
            MemoryStream ms = new MemoryStream(10000000);
            foreach (byte b in bt)
            {
                ms.WriteByte(b);
            }
            ms.Position = 0;
            BinaryFormatter bf = new BinaryFormatter();
            Object obj = bf.Deserialize(ms);
            ms.Close();
            return obj;
        }
    }

    [Serializable]
    public class sendScreen : Packet
    {
        public string order;
        public byte[] arr;

        public sendScreen()
        {
            this.order = "sendScreen";
        }
    }

    [Serializable]
    public class Paths : Packet
    {
        public string path;
        public Paths(string path)
        {
            this.path = path;
        }
        public Paths()
        {
            this.path = "";
        }
    }

    [Serializable]
    public class Fileinfo : Packet
    {
        public string path;
        public FileInfo fileinfo;
        public Fileinfo(string path)
        {
            this.path = path;
            this.fileinfo = new FileInfo(path);
        }
    }

    [Serializable]
    public class Pathinfo : Packet
    {
        public string path;
        public DirectoryInfo dir;
        public DirectoryInfo[] di;
        public FileInfo[] fi;
        public FileInfo fileinfo;
        public Pathinfo(string path)
        {
            this.path = path;
            this.dir = new DirectoryInfo(path);
            this.di = dir.GetDirectories();
            this.fi = dir.GetFiles();
            this.fileinfo = new FileInfo(path);
        }
    }

    public class Class1
    {

    }
}
